#include<stdio.h>
#include<stdlib.h>
#define MAX 6 

int main(){
	int num[MAX] = {27,7,2,9,4,85};

	/*************��w�Ƨ�*************/ 				
	for(int i=1;i<MAX;i++){
		for(int j=0;j<MAX-i;j++){
			
			/**********�L�X�B�J************/
			printf("�e�G ");
			for(int k=0;k<MAX;k++){
				printf("%d ",num[k]);
			}
			printf("\t%d �P %d ��,\ti = %d,\tj = %d\n",num[j],num[j+1],i,j); 
			/*------------End-------------*/
			
			if(num[j] > num[j+1]){
				int tmp;
				tmp = num[j];
				num[j] = num[j+1];
				num[j+1] = tmp;
			}
			
			/**********�L�X�B�J************/
			printf("��G ");
			for(int k=0;k<MAX;k++){
				printf("%d ",num[k]);
			}
			printf("\t\t\ti = %d,\tj = %d\n",i,j);
			/*------------End-------------*/
			
		}
		printf("\n");		
	}
	/**********************************/
	
	/*�L�X�ƦC��*/ 
	printf("��w�ƧǡG ");
	for(int i=0;i<MAX;i++){
		printf("%d ",num[i]);
	}
	printf("\n");
	
	
	system("pause");
	return 0;
}
