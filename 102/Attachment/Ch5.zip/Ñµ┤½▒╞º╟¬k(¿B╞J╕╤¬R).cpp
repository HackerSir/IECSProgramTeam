#include<stdio.h>
#include<stdlib.h>
#define MAX 6 

int main(){
	int num[MAX] = {27,7,2,9,4,85};
	
	/*************��ܱƧ�*************/ 				
	for(int i=0;i<MAX-1;i++){
		for(int j=i+1;j<MAX;j++){
			
			/**********�L�X�B�J************/
			printf("�e�G ");
			for(int k=0;k<MAX;k++){
				printf("%d ",num[k]);
			}
			printf("\t%d �P %d ��,\ti = %d,\tj = %d\n",num[i],num[j],i,j); 
			/*------------End-------------*/
			
			if(num[i] > num[j]){
				int tmp;
				tmp = num[i];
				num[i] = num[j];
				num[j] = tmp;
			}
			
			/**********�L�X�B�J************/
			printf("��G ");
			for(int k=0;k<MAX;k++){
				printf("%d ",num[k]);
			}
			printf("\t\t\ti = %d,\tj = %d\n",i,j);
			/*------------End-------------*/
			
		}
		printf("\n");		
	}
	/**********************************/
	
	/*�L�X�ƦC��*/ 
	printf("�洫�ƧǡG ");
	for(int i=0;i<MAX;i++){
		printf("%d ",num[i]);
	}
	printf("\n");
	
	
	system("pause");
	return 0;
}
