#include <stdio.h>
#include <stdlib.h>

enum suits {
	Spade, Heart, Diamond, Club   
};

typedef enum suits Suits;

struct card {
	Suits suit;	//��� 
	int face;	//�ƭ� 
};

typedef struct card Card;

int main() {
	Card card01 = {Diamond, 1};
	printf("%d %2d\n", card01.suit, card01.face);
	system("pause");
	return 0;	
}

