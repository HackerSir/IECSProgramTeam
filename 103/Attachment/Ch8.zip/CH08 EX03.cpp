#include <stdio.h>
#include <stdlib.h>
//�w�q���c
struct card {
	char suit;	//��� 
	int face;	//�ƭ� 
};
//�w�q�O�W
typedef struct card Card;
//�ǭȩI�s(��ӽƻs)
void printCard(Card card) {
	printf("%c%2d\n", card.suit, card.face);
}
//�ǧ}�I�s
void printCard_V2(Card *card) {
	printf("%c%2d\n", card->suit, card->face);
}
//�ǰѦҩI�s(C++)
void printCard_V3(Card &card) {
	printf("%c%2d\n", card.suit, card.face);
}

int main() {
	Card card01 = {'S', 1};
	printCard(card01);
	printCard_V2(&card01);
	printCard_V3(card01);

	system("pause");
	return 0;	
}
