#include <stdio.h>
#include <stdlib.h>
//�w�q���c
struct card {
	char suit;	//��� 
	int face;	//�ƭ� 
};
//�w�q�O�W
typedef struct card Card;

int main() {
	Card card01 = {'S', 1};
	Card *card02 = &card01;

	printf("%c%2d\n", (*card02).suit, (*card02).face);
	printf("%c%2d\n", card02->suit, card02->face);
	
	system("pause");
	return 0;	
}

