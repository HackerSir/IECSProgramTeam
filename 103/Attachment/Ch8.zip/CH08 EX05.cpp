#include <stdio.h>
#include <stdlib.h>

enum suits {
	Spade, Heart, Diamond, Club   
};
typedef enum suits Suits;

struct card {
	Suits suit;	//��� 
	int face;	//�ƭ� 
};
typedef struct card Card;

struct player {
	char name[10];
	Card crads[52];
};
typedef struct player Player;

int main() {
	Player players[4];

	system("pause");
	return 0;	
}

