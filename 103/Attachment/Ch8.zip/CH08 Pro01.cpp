#include <stdio.h>
#include <stdlib.h>
//�w�q���c
struct card {
	char suit;	//��� 
	int face;	//�ƭ� 
};
//�w�q�O�W
typedef struct card Card; 

int main() {
	//�ܽd���c�}�C 
	Card cards[52];
	
	int i;
	char suits[] = {'S', 'H', 'D', 'C'}; //suit ascii code
	for (i = 0; i < 52; i++) {
		cards[i].face = i % 13 + 1;
		cards[i].suit = suits[i / 13];
	}
	
	for (i = 0; i < 52; i++) {
		printf("%c%2d, ", cards[i].suit, cards[i].face);
		if (i % 13 == 12) printf("\n");
	}
	
	system("pause");
	return 0;	
}

