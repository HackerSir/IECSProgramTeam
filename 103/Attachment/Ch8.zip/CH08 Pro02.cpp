#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum suits {
	Spade, Heart, Diamond, Club   
};
typedef enum suits Suits;

struct card {
	Suits suit;	//��� 
	int face;	//�ƭ� 
};
typedef struct card Card;

struct player {
	Card cards[13];
};
typedef struct player Player;

int main() {
	Player players[4];
	Card cards[52];

	int i, j;
	for (i = 0; i < 52; i++) {
		int suit = i / 13;
		cards[i].suit = (suit == 0) ? Spade :
						(suit == 1) ? Heart :
						(suit == 2) ? Diamond :
						Club;
		cards[i].face = i % 13;
	}
	
	srand(time(NULL));
	for (i = 0; i < 52; i++) {
		j = rand() % 52;
		Card temp = cards[i];
		cards[i] = cards[j];
		cards[j] = temp;
	}

	for (i = 0; i < 52; i++) {
		players[i / 13].cards[i % 13] = cards[i];
	}

	for (j = 0; j < 4; j++) {
		printf("player %d:\n", j);
		for (i = 0; i < 13; i++) {
			int suit = players[j].cards[i].suit;
			printf("[%c %2d]", (suit == Spade) ? 's' :
							   (suit == Heart) ? 'h' :
							   (suit == Diamond) ? 'd' : 'c',
							   players[j].cards[i].face);
		}
		printf("\n");
	}

	system("pause");
	return 0;	
}

