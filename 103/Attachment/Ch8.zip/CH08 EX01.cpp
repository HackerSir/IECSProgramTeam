#include <stdio.h>
#include <stdlib.h>
//�w�q���c
struct card {
	char suit;	//��� 
	int face;	//�ƭ� 
};
//�w�q�O�W
typedef struct card Card;

int main() {
	struct card card01;
	Card card02;
	Card card03 = {'S', 1};

	printf("%c%2d\n", card03.suit, card03.face);
	
	system("pause");
	return 0;	
}

