#include <stdio.h>

int main() {
	int a, b;
	scanf("%d %d", &a, &b);
	
	//�����²���g�k 
	while (a != 0 && b != 0) {
		if (a > b) a = a % b;
		else b = b % a;	
	}
	
	printf("%d\n", (a == 0) ? b : a);
	
	return 0;	
}
