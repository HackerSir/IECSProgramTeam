#include <stdio.h>

int main() {
	int i, j;
	for (i = 0; i < 10; i++) {
		for (j = 0; j <= i; j++) {
			if (i == 0 || i == 10 - 1 || j == 0 || j == i) {
				printf("#");
			}
			else {	
				printf(" ");
			}
		}
		printf("\n");
	}
	return 0;
}

