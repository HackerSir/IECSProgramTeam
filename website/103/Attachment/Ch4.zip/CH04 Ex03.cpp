#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printf7rand(unsigned int seed);

int main() {
	printf7rand(100);
	printf7rand(14586);
	printf7rand(time(NULL));
	return 0;	
}

void printf7rand(unsigned int seed) {
	srand(seed);
	printf("seed = %10u -> ", seed);
	for (int i = 0; i < 7; i++) {
		printf("%5d", rand());
		if (i < 7 - 1) printf(", ");
	}
	printf("\n");
}

