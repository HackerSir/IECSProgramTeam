#include <stdio.h>

int pow(int a, int b); //a ^ b

int main() {
	printf("%d\n", pow(5, 3));
	return 0;	
}

int pow(int a, int b) {
	if (b == 1) {
		return a;
	}
	else {
		return a * pow(a, b - 1);	
	}
}

