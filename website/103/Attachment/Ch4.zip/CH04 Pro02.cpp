#include <stdio.h>

int max3(int a, int b, int c);

int main() {
	int a, b, c;
	
	while (scanf("%d %d %d", &a, &b, &c) != EOF) {
		printf("%d\n", max3(a, b, c));
	}
	
	return 0;	
}

int max3(int a, int b, int c) {
	if (c > a && c > b) return c;
	else if (b > a && b > c) return b;
	else return a;	
}

