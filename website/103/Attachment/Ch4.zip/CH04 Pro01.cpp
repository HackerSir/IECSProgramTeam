#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main() {
	int a, maxB;
	scanf("%d %d", &a, &maxB);
	
	int i;
	for (i = 1; i <= maxB; i++) {
		printf("%d ^ %2d = %8.0lf\n", a, i, pow(a, i));	
	}
	
	system("pause"); 
	return 0;	
}
