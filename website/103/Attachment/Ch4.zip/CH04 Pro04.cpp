#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

int main() {
	srand(time(NULL));
	int ans = rand() % 100 + 1;
	int number;
	while (1) {
		scanf("%d", &number);
		if (number == ans) {
			printf("���ߵ���\n");
			break;
		}
		else if (number > ans) {
			printf("�Ӥj�F\n");	
		}
		else {
			printf("�Ӥp�F\n");	
		}
	}
	return 0;
}
