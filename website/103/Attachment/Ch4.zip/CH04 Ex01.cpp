#include <stdio.h>
#include <stdlib.h>

void fun1(int a, int b);

int main() {
	int a = 5, b = 3;
	fun1(a, b);
	printf("2. a = %d, b = %d\n", a, b);
	system("pause");
	return 0;	
}

void fun1(int a, int b) {
	a += 5;
	b += 1;
	printf("1. a = %d, b = %d\n", a, b);
}

