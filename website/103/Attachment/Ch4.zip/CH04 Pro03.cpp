#include <stdio.h>
#include <stdlib.h>

int fib(int i);

int main() {
	int i;
	for (i = 0; i <= 20; i++) {
		printf("fib(%2d) = %5d\n", i, fib(i));	
	}
	system("pause");
	return 0;
}

int fib(int i) {
	if (i <= 0) return 0;
	else if (i == 1) return 1;
	else return fib(i - 1) + fib(i - 2);
}

